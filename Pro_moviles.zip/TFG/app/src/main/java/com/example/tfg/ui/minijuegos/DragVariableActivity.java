package com.example.tfg.ui.minijuegos;

import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tfg.R;
import com.example.tfg.data.JSONManager;
import com.example.tfg.ui.MapaActivity;
import com.example.tfg.ui.MinijuegoLauncherActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

public class DragVariableActivity extends AppCompatActivity {

    // Elementos visuales del minijuego
    private TextView hueco, op1, op2, op3, enunciado;

    // Respuesta correcta del minijuego
    private String respuestaCorrecta;

    // Nivel y minijuego actual
    private int nivelActual;
    private int minijuegoActual;

    // Manejo de JSON, preferencias e idioma
    private JSONManager jsonManager;
    private SharedPreferences prefs;
    private String idioma;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        // Aplica el idioma guardado antes de cargar la interfaz
        aplicarIdiomaGuardado();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.drag_variable);

        // Referencias a los elementos del layout
        enunciado = findViewById(R.id.enunciado);
        hueco = findViewById(R.id.hueco);
        op1 = findViewById(R.id.op1);
        op2 = findViewById(R.id.op2);
        op3 = findViewById(R.id.op3);

        // Configura el comportamiento del botón atrás
        configurarBack();

        // Carga preferencias e idioma
        prefs = getSharedPreferences("usuario", MODE_PRIVATE);
        idioma = prefs.getString("idioma", "es");

        // Inicializa el lector de JSON
        jsonManager = new JSONManager(this);

        // Obtiene nivel e índice del minijuego desde el intent
        nivelActual = getIntent().getIntExtra("nivel", 1);
        minijuegoActual = getIntent().getIntExtra("indiceMinijuego", 0);

        // Carga el contenido del minijuego
        cargarMinijuego();
    }

    private void cargarMinijuego() {
        try {
            // Obtiene el nivel desde el JSON
            JSONObject nivel = jsonManager.getNivel(nivelActual);
            JSONArray minijuegos = nivel.getJSONArray("minijuegos");
            JSONObject minijuego = minijuegos.getJSONObject(minijuegoActual);

            // Carga el enunciado según el idioma
            String keyEnunciado = idioma.equals("es") ? "enunciado_es" : "enunciado_en";
            enunciado.setText(minijuego.getString(keyEnunciado));

            // Carga la respuesta correcta
            String keyRespuesta = idioma.equals("es") ? "respuesta_es" : "respuesta_en";
            respuestaCorrecta = minijuego.getString(keyRespuesta);

            // Carga los distractores
            String keyDistractores = idioma.equals("es") ? "distractores_es" : "distractores_en";
            JSONArray distractores = minijuego.getJSONArray(keyDistractores);

            // Asigna textos a las opciones
            op1.setText(respuestaCorrecta);
            op2.setText(distractores.getString(0));
            op3.setText(distractores.getString(1));

            // Activa el arrastre en cada opción
            configurarDrag(op1);
            configurarDrag(op2);
            configurarDrag(op3);

            // Activa la zona donde se suelta la respuesta
            configurarDrop();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Permite arrastrar una opción
    private void configurarDrag(TextView opcion) {
        opcion.setOnTouchListener((v, event) -> {

            // Cuando el usuario toca la opción
            if (event.getAction() == MotionEvent.ACTION_DOWN) {

                // Crea un objeto con el texto arrastrado
                ClipData data = ClipData.newPlainText("variable", opcion.getText());

                // Crea la sombra visual del elemento
                View.DragShadowBuilder shadow = new View.DragShadowBuilder(v);

                // Inicia el arrastre
                v.startDragAndDrop(data, shadow, v, 0);
                return true;
            }
            return false;
        });
    }

    // Configura el área donde se suelta la respuesta
    private void configurarDrop() {
        hueco.setOnDragListener((v, event) -> {

            switch (event.getAction()) {

                // Efecto visual al entrar en el hueco
                case android.view.DragEvent.ACTION_DRAG_ENTERED:
                    hueco.setAlpha(0.5f);
                    return true;

                // Efecto visual al salir del hueco
                case android.view.DragEvent.ACTION_DRAG_EXITED:
                    hueco.setAlpha(1f);
                    return true;

                // Cuando se suelta la opción
                case android.view.DragEvent.ACTION_DROP:
                    hueco.setAlpha(1f);

                    // Obtiene el texto arrastrado
                    String texto = event.getClipData().getItemAt(0).getText().toString();
                    hueco.setText(texto);

                    // Comprueba si es correcto
                    if (texto.equals(respuestaCorrecta)) {

                        Toast.makeText(this, idioma.equals("es") ? "¡Correcto!" : "Correct!", Toast.LENGTH_SHORT).show();

                        // Avanza tras un pequeño retraso
                        new Handler().postDelayed(this::avanzar, 800);

                    } else {
                        Toast.makeText(this, idioma.equals("es") ? "Incorrecto" : "Incorrect", Toast.LENGTH_SHORT).show();
                    }

                    return true;

                // Restablece la opacidad
                case android.view.DragEvent.ACTION_DRAG_ENDED:
                    hueco.setAlpha(1f);
                    return true;
            }

            return true;
        });
    }

    // Avanza al siguiente minijuego o nivel
    private void avanzar() {

        SharedPreferences prefs = getSharedPreferences("usuario", MODE_PRIVATE);

        // Si aún quedan minijuegos en este nivel
        if (minijuegoActual < 4) {

            minijuegoActual++;
            prefs.edit().putInt("minijuego_actual", minijuegoActual).apply();

            // Vuelve al lanzador para cargar el siguiente minijuego
            new Handler().postDelayed(() -> {
                Intent i = new Intent(this, MinijuegoLauncherActivity.class);
                i.putExtra("nivel", nivelActual);
                startActivity(i);
                finish();
            }, 50);

            return;
        }

        // Si ya terminó todos los minijuegos, avanza de nivel
        nivelActual++;
        prefs.edit()
                .putInt("nivel_actual", nivelActual)
                .putInt("minijuego_actual", 0)
                .apply();

        // Vuelve al mapa
        new Handler().postDelayed(() -> {
            Intent i = new Intent(this, MapaActivity.class);
            startActivity(i);
            finish();
        }, 50);
    }

    // Diálogo de confirmación al pulsar atrás
    private void configurarBack() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                new androidx.appcompat.app.AlertDialog.Builder(DragVariableActivity.this)
                        .setTitle(idioma.equals("es") ? "Salir del nivel" : "Exit level")
                        .setMessage(idioma.equals("es")
                                ? "¿Seguro que quieres salir? Perderás el progreso de este nivel."
                                : "Are you sure you want to exit? You will lose progress in this level.")
                        .setPositiveButton(idioma.equals("es") ? "Salir" : "Exit", (dialog, which) -> finish())
                        .setNegativeButton(idioma.equals("es") ? "Cancelar" : "Cancel", (dialog, which) -> dialog.dismiss())
                        .show();
            }
        });
    }

    // Aplica el idioma guardado en preferencias
    private void aplicarIdiomaGuardado() {
        SharedPreferences prefs = getSharedPreferences("usuario", MODE_PRIVATE);
        String lang = prefs.getString("idioma", "es");

        Locale locale = new Locale(lang);
        Locale.setDefault(locale);

        Configuration config = new Configuration();
        config.setLocale(locale);

        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
    }
}
