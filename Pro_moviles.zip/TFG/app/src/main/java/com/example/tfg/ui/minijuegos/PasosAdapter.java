package com.example.tfg.ui.minijuegos;

import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tfg.R;

import java.util.List;

public class PasosAdapter extends RecyclerView.Adapter<PasosAdapter.ViewHolder> {

    private List<String> pasos;
    private OnStartDragListener dragListener;

    public PasosAdapter(List<String> pasos, OnStartDragListener dragListener) {
        this.pasos = pasos;
        this.dragListener = dragListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_paso, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.txtPaso.setText(pasos.get(position));

        holder.handle.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                dragListener.onStartDrag(holder);
            }
            return false;
        });
    }

    @Override
    public int getItemCount() {
        return pasos.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtPaso, handle;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtPaso = itemView.findViewById(R.id.txtPaso);
            handle = itemView.findViewById(R.id.handle);
        }
    }
}
