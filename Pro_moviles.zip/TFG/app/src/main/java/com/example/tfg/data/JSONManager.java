package com.example.tfg.data;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;

public class JSONManager {

    private final Context context;
    private JSONObject root;

    public JSONManager(Context context) {
        this.context = context;
        cargar();
    }

    private void cargar() {
        try {
            InputStream is = context.getAssets().open("niveles.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            root = new JSONObject(new String(buffer, "UTF-8"));
        } catch (Exception e) {
            e.printStackTrace();
            root = null;
        }
    }

    public JSONObject getNivel(int numeroNivel) {
        try {
            JSONArray niveles = root.getJSONArray("niveles");
            return niveles.getJSONObject(numeroNivel - 1);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
