package com.example.tfg.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "tfg.db";
    private static final int DATABASE_VERSION = 1;

    // Tabla de usuarios (si la usas)
    public static final String TABLE_USUARIOS = "usuarios";
    public static final String COL_USER_ID = "id";
    public static final String COL_USER_NAME = "nombre";
    public static final String COL_USER_EMAIL = "email";
    public static final String COL_USER_PASSWORD = "password";

    // Tabla de preguntas (si la usas)
    public static final String TABLE_PREGUNTAS = "preguntas";
    public static final String COL_PREG_ID = "id";
    public static final String COL_PREG_TEXTO = "pregunta";
    public static final String COL_PREG_OPCIONES = "opciones";
    public static final String COL_PREG_CORRECTA = "correcta";
    public static final String COL_PREG_CATEGORIA = "categoria";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Crear tabla de usuarios
        db.execSQL("CREATE TABLE " + TABLE_USUARIOS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USER_NAME + " TEXT, " +
                COL_USER_EMAIL + " TEXT, " +
                COL_USER_PASSWORD + " TEXT)");

        // Crear tabla de preguntas
        db.execSQL("CREATE TABLE " + TABLE_PREGUNTAS + " (" +
                COL_PREG_ID + " INTEGER PRIMARY KEY, " +
                COL_PREG_TEXTO + " TEXT, " +
                COL_PREG_OPCIONES + " TEXT, " +
                COL_PREG_CORRECTA + " INTEGER, " +
                COL_PREG_CATEGORIA + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USUARIOS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PREGUNTAS);
        onCreate(db);

    }
    // ---------------------------------------------------------
// MÉTODO: Registrar usuario
// ---------------------------------------------------------
    public boolean registrarUsuario(String nombre, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Comprobar si ya existe
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USUARIOS + " WHERE " + COL_USER_NAME + " = ?",
                new String[]{nombre}
        );

        if (cursor.getCount() > 0) {
            cursor.close();
            return false; // Usuario ya existe
        }

        cursor.close();

        ContentValues values = new ContentValues();
        values.put(COL_USER_NAME, nombre);
        values.put(COL_USER_PASSWORD, password);

        long resultado = db.insert(TABLE_USUARIOS, null, values);
        return resultado != -1;
    }

    // ---------------------------------------------------------
// MÉTODO: Validar usuario
// ---------------------------------------------------------
    public boolean validarUsuario(String nombre, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USUARIOS +
                        " WHERE " + COL_USER_NAME + " = ? AND " + COL_USER_PASSWORD + " = ?",
                new String[]{nombre, password}
        );

        boolean valido = cursor.getCount() > 0;
        cursor.close();
        return valido;
    }

}
