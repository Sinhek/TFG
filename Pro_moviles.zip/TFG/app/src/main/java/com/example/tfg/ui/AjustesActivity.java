package com.example.tfg.ui;

import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Switch;

import androidx.appcompat.app.AppCompatActivity;

import com.example.tfg.R;

import java.util.Locale;

public class AjustesActivity extends AppCompatActivity {

    private Spinner spinnerIdioma;
    private Switch switchSonido, switchMusica;
    private Button btnReset;

    private boolean primeraCarga = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        aplicarIdiomaGuardado(); // Aplicar idioma ANTES de cargar la UI
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajustes);

        spinnerIdioma = findViewById(R.id.spinnerIdioma);
        switchSonido = findViewById(R.id.switchSonido);
        switchMusica = findViewById(R.id.switchMusica);
        btnReset = findViewById(R.id.btnReset);

        configurarSpinner();
        cargarPreferencias();
        configurarEventos();
    }

    private void configurarSpinner() {
        String[] idiomas = {"Español", "English"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                idiomas
        );

        spinnerIdioma.setAdapter(adapter);
    }

    private void configurarEventos() {

        spinnerIdioma.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id) {

                if (primeraCarga) {
                    primeraCarga = false;
                    return; // Evita bucle infinito
                }

                String idioma = (position == 0) ? "es" : "en";
                cambiarIdioma(idioma);
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        switchSonido.setOnCheckedChangeListener((buttonView, isChecked) ->
                guardarBoolean("sonido", isChecked));

        switchMusica.setOnCheckedChangeListener((buttonView, isChecked) ->
                guardarBoolean("musica", isChecked));

        btnReset.setOnClickListener(v -> {
            SharedPreferences prefs = getSharedPreferences("usuario", MODE_PRIVATE);
            prefs.edit()
                    .putInt("nivel_actual", 1)
                    .putInt("minijuego_actual", 0)
                    .apply();
        });
    }

    private void cargarPreferencias() {
        SharedPreferences prefs = getSharedPreferences("usuario", MODE_PRIVATE);

        String idioma = prefs.getString("idioma", "es");
        spinnerIdioma.setSelection(idioma.equals("es") ? 0 : 1);

        switchSonido.setChecked(prefs.getBoolean("sonido", true));
        switchMusica.setChecked(prefs.getBoolean("musica", true));
    }

    private void guardarBoolean(String key, boolean value) {
        SharedPreferences prefs = getSharedPreferences("usuario", MODE_PRIVATE);
        prefs.edit().putBoolean(key, value).apply();
    }

    private void cambiarIdioma(String idioma) {
        SharedPreferences prefs = getSharedPreferences("usuario", MODE_PRIVATE);
        prefs.edit().putString("idioma", idioma).apply();

        setLocale(idioma);

        recreate(); // Recarga la Activity con el nuevo idioma
    }

    private void setLocale(String lang) {
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);

        Configuration config = new Configuration();
        config.setLocale(locale);

        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
    }

    private void aplicarIdiomaGuardado() {
        SharedPreferences prefs = getSharedPreferences("usuario", MODE_PRIVATE);
        String lang = prefs.getString("idioma", "es");
        setLocale(lang);
    }
}
