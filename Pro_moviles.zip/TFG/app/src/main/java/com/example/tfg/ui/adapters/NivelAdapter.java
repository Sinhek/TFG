package com.example.tfg.ui.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tfg.R;
import com.example.tfg.model.Nivel;
import com.example.tfg.model.NivelType;
import com.example.tfg.ui.MinijuegoLauncherActivity;

import java.util.List;

public class NivelAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final Context context;
    private final List<Nivel> niveles;
    private final RecyclerView recyclerView;

    private static final int TYPE_SECTION = 0;
    private static final int TYPE_LEVEL = 1;
    private static final int TYPE_CHEST = 2;

    public NivelAdapter(Context context, List<Nivel> niveles, RecyclerView recyclerView) {
        this.context = context;
        this.niveles = niveles;
        this.recyclerView = recyclerView;
    }

    @Override
    public int getItemViewType(int position) {
        Nivel n = niveles.get(position);

        if (n.getType() == NivelType.SECTION) return TYPE_SECTION;
        if (n.getType() == NivelType.CHEST) return TYPE_CHEST;
        return TYPE_LEVEL;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater inflater = LayoutInflater.from(context);

        if (viewType == TYPE_SECTION) {
            View view = inflater.inflate(R.layout.item_section, parent, false);
            return new SectionViewHolder(view);
        }

        if (viewType == TYPE_CHEST) {
            View view = inflater.inflate(R.layout.item_chest, parent, false);
            return new ChestViewHolder(view);
        }

        View view = inflater.inflate(R.layout.item_nivel, parent, false);
        return new NivelViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        Nivel nivel = niveles.get(position);

        // -------------------------
        // SECCIÓN
        // -------------------------
        if (holder instanceof SectionViewHolder) {
            SectionViewHolder vh = (SectionViewHolder) holder;

            vh.titulo.setText(nivel.getSectionName());

            // Icono rúnico según la sección
            switch (nivel.getSectionName()) {
                case "El Umbral del Código":
                    vh.icono.setImageResource(R.drawable.umbral_portal);
                    break;

                case "Fundamentos del Núcleo":
                    vh.icono.setImageResource(R.drawable.fundamentos_del_nucleo);
                    break;

                case "Ascenso del Arquitecto":
                    vh.icono.setImageResource(R.drawable.ascenso_arq);
                    break;

                default:
                    vh.icono.setImageResource(R.drawable.ic_portal_codigo);
                    break;
            }


            // Scroll suave al tocar la sección
            vh.itemView.setOnClickListener(v ->
                    recyclerView.smoothScrollToPosition(holder.getAdapterPosition())
            );

            return;
        }

        // -------------------------
        // COFRE
        // -------------------------
        if (holder instanceof ChestViewHolder) {
            ChestViewHolder vh = (ChestViewHolder) holder;

            vh.icono.setImageResource(R.drawable.ic_chest);
            vh.icono.setAlpha(nivel.isUnlocked() ? 1f : 0.3f);
            return;
        }

        // -------------------------
        // NIVEL NORMAL
        // -------------------------
        NivelViewHolder vh = (NivelViewHolder) holder;

        // Icono rúnico del nivel
        vh.icono.setImageResource(nivel.getIconRes());

        // Número del nivel
        vh.numero.setText(String.valueOf(nivel.getLevelNumber()));

        // Estado visual
        if (!nivel.isUnlocked()) {
            vh.icono.setAlpha(0.3f);
            vh.numero.setAlpha(0.3f);
        } else {
            vh.icono.setAlpha(1f);
            vh.numero.setAlpha(1f);

            vh.itemView.setOnClickListener(v -> {
                Intent intent = new Intent(context, MinijuegoLauncherActivity.class);
                intent.putExtra("nivel", nivel.getLevelNumber());
                context.startActivity(intent);
            });
        }

        // -------------------------
        // ZIG-ZAG CENTRADO
        // -------------------------
        ViewGroup.LayoutParams baseParams = vh.itemView.getLayoutParams();

        if (baseParams instanceof RecyclerView.LayoutParams) {
            RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) baseParams;

            int margin = 120;

            if (position % 2 == 0) {
                params.setMarginStart(margin);
                params.setMarginEnd(0);
            } else {
                params.setMarginStart(0);
                params.setMarginEnd(margin);
            }

            vh.itemView.setLayoutParams(params);
        }
    }

    @Override
    public int getItemCount() {
        return niveles.size();
    }

    // ---------------------------------------------------------
    // VIEW HOLDERS
    // ---------------------------------------------------------

    static class NivelViewHolder extends RecyclerView.ViewHolder {
        ImageView icono;
        TextView numero;

        public NivelViewHolder(@NonNull View itemView) {
            super(itemView);
            icono = itemView.findViewById(R.id.iconNivel);
            numero = itemView.findViewById(R.id.txtNumeroNivel);
        }
    }

    static class SectionViewHolder extends RecyclerView.ViewHolder {
        ImageView icono;
        TextView titulo;

        public SectionViewHolder(@NonNull View itemView) {
            super(itemView);
            icono = itemView.findViewById(R.id.iconSeccion);
            titulo = itemView.findViewById(R.id.txtTituloSeccion);
        }
    }

    static class ChestViewHolder extends RecyclerView.ViewHolder {
        ImageView icono;

        public ChestViewHolder(@NonNull View itemView) {
            super(itemView);
            icono = itemView.findViewById(R.id.iconChest);
        }
    }
}
