package com.example.tfg.ui.minijuegos;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tfg.R;
import com.example.tfg.data.JSONManager;
import com.example.tfg.ui.MapaActivity;
import com.example.tfg.ui.MinijuegoLauncherActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class OrdenarPasosActivity extends AppCompatActivity implements OnStartDragListener {

    // RecyclerView donde se muestran los pasos
    private RecyclerView recycler;

    // Adaptador del RecyclerView
    private PasosAdapter adapter;

    // Controlador para arrastrar y mover elementos
    private ItemTouchHelper helper;

    // Lista con los pasos correctos (orden real)
    private List<String> pasosCorrectos;

    // Lista con los pasos desordenados que ve el jugador
    private List<String> pasosJugador;

    // Nivel y minijuego actual
    private int nivelActual;
    private int minijuegoActual;

    // Manejo de JSON, preferencias e idioma
    private JSONManager jsonManager;
    private SharedPreferences prefs;
    private String idioma;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        // Aplica el idioma guardado antes de cargar la interfaz
        aplicarIdiomaGuardado();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.ordenar_pasos);

        // Configura el RecyclerView
        recycler = findViewById(R.id.recyclerPasos);
        recycler.setLayoutManager(new LinearLayoutManager(this));

        // Configura el botón atrás con confirmación
        configurarBack();

        // Carga preferencias e idioma
        prefs = getSharedPreferences("usuario", MODE_PRIVATE);
        idioma = prefs.getString("idioma", "es");

        // Inicializa el lector de JSON
        jsonManager = new JSONManager(this);

        // Obtiene nivel e índice del minijuego desde el intent
        nivelActual = getIntent().getIntExtra("nivel", 1);
        minijuegoActual = getIntent().getIntExtra("indiceMinijuego", 0);

        // Carga los pasos del minijuego
        cargarMinijuego();
    }

    private void cargarMinijuego() {
        try {
            // Obtiene el nivel desde el JSON
            JSONObject nivel = jsonManager.getNivel(nivelActual);
            JSONArray minijuegos = nivel.getJSONArray("minijuegos");
            JSONObject minijuego = minijuegos.getJSONObject(minijuegoActual);

            // Obtiene los pasos correctos según el idioma
            String keyPasos = idioma.equals("es") ? "pasos_correctos_es" : "pasos_correctos_en";
            JSONArray arr = minijuego.getJSONArray(keyPasos);

            // Guarda los pasos correctos en una lista
            pasosCorrectos = new ArrayList<>();
            for (int i = 0; i < arr.length(); i++) {
                pasosCorrectos.add(arr.getString(i));
            }

            // Copia los pasos y los mezcla para mostrarlos desordenados
            pasosJugador = new ArrayList<>(pasosCorrectos);
            Collections.shuffle(pasosJugador);

            // Crea el adaptador con los pasos desordenados
            adapter = new PasosAdapter(pasosJugador, this);
            recycler.setAdapter(adapter);

            // Permite arrastrar y mover elementos
            helper = new ItemTouchHelper(simpleCallback);
            helper.attachToRecyclerView(recycler);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Método de la interfaz OnStartDragListener → inicia el arrastre
    @Override
    public void onStartDrag(RecyclerView.ViewHolder viewHolder) {
        helper.startDrag(viewHolder);
    }

    // Avanza al siguiente minijuego o nivel
    private void avanzar() {
        SharedPreferences prefs = getSharedPreferences("usuario", MODE_PRIVATE);

        // Si aún quedan minijuegos en este nivel
        if (minijuegoActual < 4) {

            minijuegoActual++;
            prefs.edit().putInt("minijuego_actual", minijuegoActual).apply();

            // Vuelve al lanzador para cargar el siguiente minijuego
            new Handler().postDelayed(() -> {
                Intent i = new Intent(this, MinijuegoLauncherActivity.class);
                i.putExtra("nivel", nivelActual);
                startActivity(i);
                finish();
            }, 50);

            return;
        }

        // Si ya terminó todos los minijuegos, avanza de nivel
        nivelActual++;
        prefs.edit()
                .putInt("nivel_actual", nivelActual)
                .putInt("minijuego_actual", 0)
                .apply();

        // Vuelve al mapa
        new Handler().postDelayed(() -> {
            Intent i = new Intent(this, MapaActivity.class);
            startActivity(i);
            finish();
        }, 50);
    }

    // Callback que controla el arrastre y movimiento de los pasos
    ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP | ItemTouchHelper.DOWN, // Permite mover arriba y abajo
            0 // No permite deslizar para borrar
    ) {
        @Override
        public boolean onMove(RecyclerView rv, RecyclerView.ViewHolder vh, RecyclerView.ViewHolder target) {

            // Posiciones de origen y destino
            int from = vh.getAdapterPosition();
            int to = target.getAdapterPosition();

            // Intercambia los elementos en la lista
            Collections.swap(pasosJugador, from, to);

            // Notifica al adaptador del movimiento
            adapter.notifyItemMoved(from, to);

            // Comprueba si el jugador ha ordenado correctamente
            if (pasosJugador.equals(pasosCorrectos)) {

                Toast.makeText(
                        OrdenarPasosActivity.this,
                        idioma.equals("es") ? "¡Correcto!" : "Correct!",
                        Toast.LENGTH_SHORT
                ).show();

                // Avanza tras un pequeño retraso
                new Handler().postDelayed(() -> avanzar(), 800);
            }

            return true;
        }

        @Override
        public boolean isLongPressDragEnabled() {
            // El arrastre solo se activa desde el icono del adaptador
            return false;
        }

        @Override
        public void onSwiped(RecyclerView.ViewHolder vh, int direction) {
            // No se usa porque no hay swipe
        }
    };

    // Diálogo de confirmación al pulsar atrás
    private void configurarBack() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                new androidx.appcompat.app.AlertDialog.Builder(OrdenarPasosActivity.this)
                        .setTitle(idioma.equals("es") ? "Salir del nivel" : "Exit level")
                        .setMessage(idioma.equals("es")
                                ? "¿Seguro que quieres salir? Perderás el progreso de este nivel."
                                : "Are you sure you want to exit? You will lose progress in this level.")
                        .setPositiveButton(idioma.equals("es") ? "Salir" : "Exit", (dialog, which) -> finish())
                        .setNegativeButton(idioma.equals("es") ? "Cancelar" : "Cancel", (dialog, which) -> dialog.dismiss())
                        .show();
            }
        });
    }

    // Aplica el idioma guardado en preferencias
    private void aplicarIdiomaGuardado() {
        SharedPreferences prefs = getSharedPreferences("usuario", MODE_PRIVATE);
        String lang = prefs.getString("idioma", "es");

        Locale locale = new Locale(lang);
        Locale.setDefault(locale);

        Configuration config = new Configuration();
        config.setLocale(locale);

        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
    }
}
