package com.example.tfg.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.example.tfg.data.JSONManager;
import com.example.tfg.ui.minijuegos.DragVariableActivity;
import com.example.tfg.ui.minijuegos.OrdenarPasosActivity;
import com.example.tfg.ui.minijuegos.TestActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

public class MinijuegoLauncherActivity extends AppCompatActivity {

    private int nivel;
    private int indiceMinijuego;
    private JSONManager jsonManager;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        aplicarIdiomaGuardado();
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences("usuario", MODE_PRIVATE);
        jsonManager = new JSONManager(this);

        nivel = getIntent().getIntExtra("nivel", 1);
        indiceMinijuego = prefs.getInt("minijuego_actual", 0);

        lanzar();
    }

    private void lanzar() {
        try {
            JSONObject nivelObj = jsonManager.getNivel(nivel);
            JSONArray minijuegos = nivelObj.getJSONArray("minijuegos");

            if (indiceMinijuego >= minijuegos.length()) {

                int nivelActual = prefs.getInt("nivel_actual", 1);
                if (nivel == nivelActual && nivel < 15) {
                    prefs.edit().putInt("nivel_actual", nivel + 1).apply();
                }

                prefs.edit().putInt("minijuego_actual", 0).apply();
                finish();
                return;
            }

            JSONObject minijuego = minijuegos.getJSONObject(indiceMinijuego);
            String tipo = minijuego.getString("tipo");

            Intent intent;

            switch (tipo) {
                case "test":
                    intent = new Intent(this, TestActivity.class);
                    break;
                case "drag":
                    intent = new Intent(this, DragVariableActivity.class);
                    break;
                default:
                    intent = new Intent(this, OrdenarPasosActivity.class);
                    break;
            }

            intent.putExtra("nivel", nivel);
            intent.putExtra("indiceMinijuego", indiceMinijuego);

            new Handler().postDelayed(() -> {
                startActivity(intent);
                finish();
            }, 50);

        } catch (Exception e) {
            e.printStackTrace();
            finish();
        }
    }

    private void aplicarIdiomaGuardado() {
        SharedPreferences prefs = getSharedPreferences("usuario", MODE_PRIVATE);
        String lang = prefs.getString("idioma", "es");

        Locale locale = new Locale(lang);
        Locale.setDefault(locale);

        Configuration config = new Configuration();
        config.setLocale(locale);

        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
    }
}
