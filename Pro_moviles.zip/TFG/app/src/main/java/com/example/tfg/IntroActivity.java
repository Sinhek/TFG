package com.example.tfg;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.tfg.ui.LoginActivity;

import java.util.Locale;

public class IntroActivity extends AppCompatActivity {

    private boolean alreadyLaunched = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        aplicarIdiomaGuardado();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);

        VideoView videoView = findViewById(R.id.videoIntro);

        Uri video = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.intro);
        videoView.setVideoURI(video);

        // 🔥 Delay para evitar que Android mate la Activity antes de tiempo
        new Handler().postDelayed(() -> videoView.start(), 150);

        videoView.setOnCompletionListener(mp -> {
            if (alreadyLaunched) return; // Evita doble ejecución
            alreadyLaunched = true;

            // 🔥 Delay para evitar el crash TopResumedActivityChangeItem
            new Handler().postDelayed(() -> {
                Intent intent = new Intent(IntroActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }, 150);
        });
    }

    private void aplicarIdiomaGuardado() {
        SharedPreferences prefs = getSharedPreferences("usuario", MODE_PRIVATE);
        String lang = prefs.getString("idioma", "es");

        Locale locale = new Locale(lang);
        Locale.setDefault(locale);

        Configuration config = new Configuration();
        config.setLocale(locale);

        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
    }
}
