package com.example.tfg.ui;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.tfg.R;
import com.example.tfg.data.DatabaseHelper;
import com.example.tfg.utiles.RecordatorioReceiver;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Locale;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText edtUsuario, edtPassword;
    private MaterialButton btnLogin;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        aplicarIdiomaGuardado();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new DatabaseHelper(this);

        edtUsuario = findViewById(R.id.edtUsuario);
        edtPassword = findViewById(R.id.edtPassword);
        btnLogin = findViewById(R.id.btnLogin);

        // -----------------------------
        // BOTÓN LOGIN
        // -----------------------------
        btnLogin.setOnClickListener(v -> {

            String usuario = edtUsuario.getText().toString().trim();
            String password = edtPassword.getText().toString().trim();

            if (usuario.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, getString(R.string.login_fill_fields), Toast.LENGTH_SHORT).show();
            }
            else if (dbHelper.validarUsuario(usuario, password)) {

                // 🔔 PROGRAMAR NOTIFICACIÓN DIARIA
                programarRecordatorio();

                Intent intent = new Intent(this, MapaActivity.class);
                intent.putExtra("usuario", usuario);
                startActivity(intent);

            } else {
                Toast.makeText(this, getString(R.string.login_wrong_credentials), Toast.LENGTH_SHORT).show();
            }
        });

        // -----------------------------
        // BOTÓN REGISTRO
        // -----------------------------
        findViewById(R.id.txtRegister).setOnClickListener(v -> {

            String usuario = edtUsuario.getText().toString().trim();
            String password = edtPassword.getText().toString().trim();

            if (usuario.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, getString(R.string.login_fill_fields), Toast.LENGTH_SHORT).show();
            }
            else if (dbHelper.registrarUsuario(usuario, password)) {
                Toast.makeText(this, getString(R.string.login_registered), Toast.LENGTH_LONG).show();
            }
            else {
                Toast.makeText(this, getString(R.string.login_exists), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ---------------------------------------------------------
    // 🔔 PROGRAMAR NOTIFICACIÓN DIARIA
    // ---------------------------------------------------------
    private void programarRecordatorio() {

        Intent intent = new Intent(this, RecordatorioReceiver.class);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

        long triggerAt = System.currentTimeMillis() + 24 * 60 * 60 * 1000; // 24h

        alarmManager.setRepeating(
                AlarmManager.RTC_WAKEUP,
                triggerAt,
                24 * 60 * 60 * 1000,
                pendingIntent
        );
    }

    // ---------------------------------------------------------
    // IDIOMA GUARDADO
    // ---------------------------------------------------------
    private void aplicarIdiomaGuardado() {

        SharedPreferences prefs = getSharedPreferences("usuario", MODE_PRIVATE);
        String lang = prefs.getString("idioma", "es");

        Locale locale = new Locale(lang);
        Locale.setDefault(locale);

        Configuration config = new Configuration();
        config.setLocale(locale);

        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
    }
}
