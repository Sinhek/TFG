package com.example.tfg.ui;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tfg.R;
import com.google.android.material.card.MaterialCardView;

public class MenuActivity extends AppCompatActivity {

    private MaterialCardView cardPerfil, cardMapa, cardAjustes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        cardPerfil = findViewById(R.id.cardPerfil);
        cardMapa = findViewById(R.id.cardMapa);
        cardAjustes = findViewById(R.id.cardAjustes);

        cardPerfil.setOnClickListener(v ->
                startActivity(new Intent(this, PerfilActivity.class)));

        cardMapa.setOnClickListener(v ->
                startActivity(new Intent(this, MapaActivity.class)));

        cardAjustes.setOnClickListener(v ->
                startActivity(new Intent(this, AjustesActivity.class)));
    }
}
