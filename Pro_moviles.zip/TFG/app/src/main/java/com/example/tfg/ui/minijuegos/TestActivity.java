package com.example.tfg.ui.minijuegos;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tfg.R;
import com.example.tfg.data.JSONManager;
import com.example.tfg.ui.MapaActivity;
import com.example.tfg.ui.MinijuegoLauncherActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

public class TestActivity extends AppCompatActivity {

    private TextView enunciado;
    private Button op1, op2, op3;

    private int correcta;

    private int nivelActual;
    private int minijuegoActual;

    private JSONManager jsonManager;
    private SharedPreferences prefs;
    private String idioma;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        aplicarIdiomaGuardado();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_layout);

        enunciado = findViewById(R.id.txtEnunciado);
        op1 = findViewById(R.id.btnOp1);
        op2 = findViewById(R.id.btnOp2);
        op3 = findViewById(R.id.btnOp3);

        configurarBack();

        prefs = getSharedPreferences("usuario", MODE_PRIVATE);
        idioma = prefs.getString("idioma", "es");

        jsonManager = new JSONManager(this);

        nivelActual = getIntent().getIntExtra("nivel", 1);
        minijuegoActual = getIntent().getIntExtra("indiceMinijuego", 0);

        cargarMinijuego();

        op1.setOnClickListener(v -> comprobar(0));
        op2.setOnClickListener(v -> comprobar(1));
        op3.setOnClickListener(v -> comprobar(2));
    }

    private void cargarMinijuego() {
        try {
            JSONObject nivel = jsonManager.getNivel(nivelActual);
            JSONArray minijuegos = nivel.getJSONArray("minijuegos");
            JSONObject minijuego = minijuegos.getJSONObject(minijuegoActual);

            String keyEnunciado = idioma.equals("es") ? "enunciado_es" : "enunciado_en";
            enunciado.setText(minijuego.getString(keyEnunciado));

            String keyOpciones = idioma.equals("es") ? "opciones_es" : "opciones_en";
            JSONArray opciones = minijuego.getJSONArray(keyOpciones);

            correcta = minijuego.getInt("correcta");

            op1.setText(opciones.getString(0));
            op2.setText(opciones.getString(1));
            op3.setText(opciones.getString(2));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void comprobar(int seleccion) {

        boolean esCorrecto = (seleccion == correcta);

        if (esCorrecto) {
            Toast.makeText(this, idioma.equals("es") ? "¡Correcto!" : "Correct!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, idioma.equals("es") ? "Incorrecto" : "Incorrect!", Toast.LENGTH_SHORT).show();
        }

        new Handler().postDelayed(this::avanzar, 800);
    }

    private void avanzar() {

        SharedPreferences prefs = getSharedPreferences("usuario", MODE_PRIVATE);

        if (minijuegoActual < 4) {

            minijuegoActual++;
            prefs.edit().putInt("minijuego_actual", minijuegoActual).apply();

            new Handler().postDelayed(() -> {
                Intent i = new Intent(this, MinijuegoLauncherActivity.class);
                i.putExtra("nivel", nivelActual);
                startActivity(i);
                finish();
            }, 50);

            return;
        }

        nivelActual++;
        prefs.edit()
                .putInt("nivel_actual", nivelActual)
                .putInt("minijuego_actual", 0)
                .apply();

        new Handler().postDelayed(() -> {
            Intent i = new Intent(this, MapaActivity.class);
            startActivity(i);
            finish();
        }, 50);
    }

    private void configurarBack() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                new androidx.appcompat.app.AlertDialog.Builder(TestActivity.this)
                        .setTitle(idioma.equals("es") ? "Salir del nivel" : "Exit level")
                        .setMessage(idioma.equals("es")
                                ? "¿Seguro que quieres salir? Perderás el progreso de este nivel."
                                : "Are you sure you want to exit? You will lose progress in this level.")
                        .setPositiveButton(idioma.equals("es") ? "Salir" : "Exit", (dialog, which) -> finish())
                        .setNegativeButton(idioma.equals("es") ? "Cancelar" : "Cancel", (dialog, which) -> dialog.dismiss())
                        .show();
            }
        });
    }

    private void aplicarIdiomaGuardado() {
        SharedPreferences prefs = getSharedPreferences("usuario", MODE_PRIVATE);
        String lang = prefs.getString("idioma", "es");

        Locale locale = new Locale(lang);
        Locale.setDefault(locale);

        Configuration config = new Configuration();
        config.setLocale(locale);

        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
    }
}
