package com.example.tfg.ui;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.example.tfg.R;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.imageview.ShapeableImageView;

import java.io.ByteArrayOutputStream;
import java.util.Locale;
import android.content.res.Configuration;

public class PerfilActivity extends AppCompatActivity {

    // Elementos visuales del perfil
    private ShapeableImageView imgAvatar;
    private TextView txtNombre, txtNivel;
    private MaterialButton btnCambiarFoto;
    private ImageView btnEditarNombre;

    // Launcher para abrir la cámara y recibir la foto
    private final ActivityResultLauncher<Intent> cameraLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {

                // Comprueba que la foto se tomó correctamente
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {

                    Bitmap foto = (Bitmap) result.getData().getExtras().get("data");

                    // Si la foto existe, mostrarla y guardarla
                    if (foto != null) {
                        Glide.with(this)
                                .load(foto)
                                .circleCrop()
                                .into(imgAvatar);

                        guardarAvatar(foto);
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        // Aplica el idioma guardado antes de cargar la interfaz
        aplicarIdiomaGuardado();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);

        // Referencias a los elementos del layout
        imgAvatar = findViewById(R.id.imgAvatarPerfil);
        txtNombre = findViewById(R.id.txtNombrePerfil);
        txtNivel = findViewById(R.id.txtNivelPerfil);
        btnCambiarFoto = findViewById(R.id.btnCambiarFoto);
        btnEditarNombre = findViewById(R.id.btnEditarNombre);

        // Carga nombre, nivel y avatar del usuario
        cargarDatosUsuario();

        // Listeners para cambiar foto y nombre
        btnCambiarFoto.setOnClickListener(v -> abrirCamara());
        txtNombre.setOnClickListener(v -> mostrarDialogoCambiarNombre());
        btnEditarNombre.setOnClickListener(v -> mostrarDialogoCambiarNombre());

        // Animación de entrada para mejorar la experiencia visual
        animarEntrada();
    }

    // ---------------------------------------------------------
    // CARGAR DATOS DEL USUARIO (nombre, nivel, avatar)
    // ---------------------------------------------------------
    private void cargarDatosUsuario() {

        SharedPreferences prefs = getSharedPreferences("usuario", MODE_PRIVATE);

        String nombre = prefs.getString("nombre", getString(R.string.profile_user));
        String avatarBase64 = prefs.getString("avatar", null);
        int nivel = prefs.getInt("nivel_actual", 1);

        // Muestra nombre y nivel
        txtNombre.setText(nombre);
        txtNivel.setText(getString(R.string.profile_level, nivel));

        // Si hay avatar guardado → decodificarlo y mostrarlo
        if (avatarBase64 != null) {

            byte[] bytes = Base64.decode(avatarBase64, Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);

            Glide.with(this)
                    .load(bitmap)
                    .circleCrop()
                    .into(imgAvatar);

        } else {
            // Avatar por defecto
            Glide.with(this)
                    .load(R.drawable.ic_user)
                    .circleCrop()
                    .into(imgAvatar);
        }
    }

    // ---------------------------------------------------------
    // CAMBIAR NOMBRE DEL USUARIO
    // ---------------------------------------------------------
    private void mostrarDialogoCambiarNombre() {

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Cambiar nombre");

        // Campo de texto para introducir el nuevo nombre
        final EditText input = new EditText(this);
        input.setHint("Nuevo nombre");
        input.setText(txtNombre.getText().toString());
        builder.setView(input);

        // Botón guardar
        builder.setPositiveButton("Guardar", (dialog, which) -> {

            String nuevoNombre = input.getText().toString().trim();

            if (!nuevoNombre.isEmpty()) {

                SharedPreferences prefs = getSharedPreferences("usuario", MODE_PRIVATE);
                prefs.edit().putString("nombre", nuevoNombre).apply();

                txtNombre.setText(nuevoNombre);
            }
        });

        // Botón cancelar
        builder.setNegativeButton("Cancelar", (dialog, which) -> dialog.dismiss());

        builder.show();
    }

    // ---------------------------------------------------------
    // ABRIR CÁMARA PARA CAMBIAR AVATAR
    // ---------------------------------------------------------
    private void abrirCamara() {

        // Comprueba permisos de cámara
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(new String[]{Manifest.permission.CAMERA}, 0);

        } else {
            // Abre la cámara
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cameraLauncher.launch(intent);
        }
    }

    // ---------------------------------------------------------
    // GUARDAR AVATAR EN BASE64
    // ---------------------------------------------------------
    private void guardarAvatar(Bitmap bitmap) {

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);

        String base64 = Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT);

        SharedPreferences prefs = getSharedPreferences("usuario", MODE_PRIVATE);
        prefs.edit().putString("avatar", base64).apply();
    }

    // ---------------------------------------------------------
    // APLICAR IDIOMA GUARDADO
    // ---------------------------------------------------------
    private void aplicarIdiomaGuardado() {

        SharedPreferences prefs = getSharedPreferences("usuario", MODE_PRIVATE);
        String lang = prefs.getString("idioma", "es");

        Locale locale = new Locale(lang);
        Locale.setDefault(locale);

        Configuration config = new Configuration();
        config.setLocale(locale);

        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
    }

    // ---------------------------------------------------------
    // ANIMACIÓN DE ENTRADA DEL PERFIL
    // ---------------------------------------------------------
    private void animarEntrada() {

        // Avatar aparece suavemente
        imgAvatar.setAlpha(0f);
        imgAvatar.animate().alpha(1f).setDuration(400).start();

        // Nombre baja desde arriba con fade
        txtNombre.setTranslationY(40f);
        txtNombre.setAlpha(0f);
        txtNombre.animate().translationY(0f).alpha(1f).setDuration(400).setStartDelay(150).start();

        // Nivel también aparece con animación
        txtNivel.setTranslationY(40f);
        txtNivel.setAlpha(0f);
        txtNivel.animate().translationY(0f).alpha(1f).setDuration(400).setStartDelay(250).start();
    }
}
