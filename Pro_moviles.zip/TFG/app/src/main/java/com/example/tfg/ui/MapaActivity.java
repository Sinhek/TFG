package com.example.tfg.ui;

import com.bumptech.glide.Glide;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tfg.R;
import com.example.tfg.model.Nivel;
import com.example.tfg.model.NivelType;
import com.example.tfg.ui.adapters.NivelAdapter;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MapaActivity extends AppCompatActivity {

    // RecyclerView que contiene todas las secciones, niveles y cofres
    private RecyclerView recyclerView;

    // Nombre del usuario mostrado en el header
    private TextView txtNombreUsuario;

    // Adaptador del mapa
    private NivelAdapter adapter;

    // Lista completa de niveles, secciones y cofres
    private List<Nivel> listaNiveles;

    // Botón del avatar (abre menú Perfil/Ajustes)
    private ImageView avatarBtn;

    // LayoutManager para el RecyclerView
    private LinearLayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        // Aplica el idioma guardado antes de cargar la interfaz
        aplicarIdiomaGuardado();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mapa);

        // Referencias a elementos del layout
        recyclerView = findViewById(R.id.recyclerMapa);
        avatarBtn = findViewById(R.id.avatarBtn);
        txtNombreUsuario = findViewById(R.id.txtNombreUsuario);

        // Configura el RecyclerView en modo vertical
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        // Genera la estructura del mapa (secciones, niveles, cofres)
        generarListaNiveles();

        // Aplica el progreso guardado (niveles desbloqueados)
        aplicarProgresoGuardado();

        // Crea el adaptador y lo asigna al RecyclerView
        adapter = new NivelAdapter(this, listaNiveles, recyclerView);
        recyclerView.setAdapter(adapter);

        // Añade padding lateral para el efecto zig‑zag
        recyclerView.setPadding(200, 0, 200, 0);

        // Carga avatar y nombre del usuario
        cargarAvatar();
        configurarAvatar();
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarAvatar();  // Actualiza avatar si se cambió en Perfil
        cargarNombre();  // Actualiza nombre si se cambió en Perfil
    }

    // ---------------------------------------------------------
    // CARGAR AVATAR DEL USUARIO
    // ---------------------------------------------------------
    private void cargarAvatar() {

        // Accede a las preferencias del usuario
        SharedPreferences prefs = getSharedPreferences("usuario", MODE_PRIVATE);
        String avatarBase64 = prefs.getString("avatar", null);

        // Si existe un avatar guardado → decodificarlo y mostrarlo
        if (avatarBase64 != null) {

            byte[] bytes = Base64.decode(avatarBase64, Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);

            Glide.with(this)
                    .load(bitmap)
                    .circleCrop()
                    .into(avatarBtn);

        } else {
            // Si no hay avatar → icono por defecto
            avatarBtn.setImageResource(R.drawable.ic_user);
        }
    }

    // ---------------------------------------------------------
    // GENERAR LISTA DE NIVELES, SECCIONES Y COFRES
    // ---------------------------------------------------------
    private void generarListaNiveles() {

        listaNiveles = new ArrayList<>();

        // Iconos de colores para niveles
        int iconoVerde = R.drawable.ic_nivel_verde;
        int iconoAzul = R.drawable.ic_nivel_azul;
        int iconoMorado = R.drawable.ic_nivel_morado;

        // SECCIÓN 1
        listaNiveles.add(new Nivel(NivelType.SECTION, getString(R.string.section_intro), null, true, 0));

        // Niveles 1–5
        for (int i = 1; i <= 5; i++) {
            listaNiveles.add(new Nivel(NivelType.LEVEL, null, i, i == 1, iconoVerde));
        }

        // Cofre final de sección
        listaNiveles.add(new Nivel(NivelType.CHEST, null, null, false, R.drawable.ic_chest));

        // SECCIÓN 2
        listaNiveles.add(new Nivel(NivelType.SECTION, getString(R.string.section_basic), null, false, 0));

        // Niveles 6–10
        for (int i = 6; i <= 10; i++) {
            listaNiveles.add(new Nivel(NivelType.LEVEL, null, i, false, iconoAzul));
        }

        // Cofre final de sección
        listaNiveles.add(new Nivel(NivelType.CHEST, null, null, false, R.drawable.ic_chest));

        // SECCIÓN 3
        listaNiveles.add(new Nivel(NivelType.SECTION, getString(R.string.section_challenges), null, false, 0));

        // Niveles 11–15
        for (int i = 11; i <= 15; i++) {
            listaNiveles.add(new Nivel(NivelType.LEVEL, null, i, false, iconoMorado));
        }

        // Cofre final de sección
        listaNiveles.add(new Nivel(NivelType.CHEST, null, null, false, R.drawable.ic_chest));
    }

    // ---------------------------------------------------------
    // APLICAR PROGRESO GUARDADO (NIVELES DESBLOQUEADOS)
    // ---------------------------------------------------------
    private void aplicarProgresoGuardado() {

        SharedPreferences prefs = getSharedPreferences("usuario", MODE_PRIVATE);

        // Nivel máximo desbloqueado por el usuario
        int nivelDesbloqueado = prefs.getInt("nivel_actual", 1);

        // Desbloquea todos los niveles <= nivel guardado
        for (Nivel n : listaNiveles) {
            if (n.getLevelNumber() != null && n.getLevelNumber() <= nivelDesbloqueado) {
                n.setUnlocked(true);
            }
        }
    }

    // ---------------------------------------------------------
    // MENÚ DEL AVATAR (Perfil / Ajustes)
    // ---------------------------------------------------------
    private void configurarAvatar() {

        avatarBtn.setOnClickListener(v -> {

            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle(getString(R.string.settings_title))
                    .setItems(new String[]{
                            getString(R.string.go_profile),   // Ir al perfil
                            getString(R.string.settings)      // Ir a ajustes
                    }, (d, which) -> {

                        d.dismiss();

                        switch (which) {
                            case 0:
                                startActivity(new Intent(this, PerfilActivity.class));
                                break;

                            case 1:
                                startActivity(new Intent(this, AjustesActivity.class));
                                break;
                        }
                    })
                    .create();

            dialog.show();
        });
    }

    // ---------------------------------------------------------
    // APLICAR IDIOMA GUARDADO
    // ---------------------------------------------------------
    private void aplicarIdiomaGuardado() {

        SharedPreferences prefs = getSharedPreferences("usuario", MODE_PRIVATE);
        String lang = prefs.getString("idioma", "es");

        Locale locale = new Locale(lang);
        Locale.setDefault(locale);

        Configuration config = new Configuration();
        config.setLocale(locale);

        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
    }

    // ---------------------------------------------------------
    // CARGAR NOMBRE DEL USUARIO
    // ---------------------------------------------------------
    private void cargarNombre() {

        SharedPreferences prefs = getSharedPreferences("usuario", MODE_PRIVATE);
        String nombre = prefs.getString("nombre", "Usuario");

        if (txtNombreUsuario != null) {
            txtNombreUsuario.setText(nombre);
        }
    }
}
