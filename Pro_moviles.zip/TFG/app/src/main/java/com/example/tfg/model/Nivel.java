package com.example.tfg.model;

public class Nivel {

    private NivelType type;
    private String sectionName;
    private Integer levelNumber;
    private boolean unlocked;
    private int iconRes;

    public Nivel(NivelType type, String sectionName, Integer levelNumber, boolean unlocked, int iconRes) {
        this.type = type;
        this.sectionName = sectionName;
        this.levelNumber = levelNumber;
        this.unlocked = unlocked;
        this.iconRes = iconRes;
    }

    public NivelType getType() {
        return type;
    }

    public String getSectionName() {
        return sectionName;
    }

    public Integer getLevelNumber() {
        return levelNumber;
    }

    public boolean isUnlocked() {
        return unlocked;
    }

    public void setUnlocked(boolean unlocked) {
        this.unlocked = unlocked;
    }

    public int getIconRes() {
        return iconRes;
    }
}
