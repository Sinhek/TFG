package com.example.tfg.model;

public enum NivelType {
    SECTION,
    LEVEL,
    CHEST
}
